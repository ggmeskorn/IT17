<?php
$db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
    $user_email = $_POST['user_email'];
    $post_id = $_POST['post_id'];
    $isLike = $_POST['isLike'];
    $curDate = date('d/m/Y');

    $result = $db->query("SELECT * FROM post_likes WHERE user_email = '".$user_email."' AND post_id = '".$post_id."'");

    $count = mysqli_num_rows($result);
    if($count == 1){
        echo json_encode("ONE");
    }else{
        echo json_encode("TWO");
    }

    // $sql = "INSERT INTO `register`(`id`, `email`, `username`,`password`,`gender`,`pathImage`,`status`) VALUES (Null, '$email','$username','$password','$gender','$pathImage','$status')";

    // $db->query("INSERT INTO post_likes(user_email,post_id,isLike,like_date)VALUES('".$user_email."','".$post_id."','".$isLike."','".$curDate."')");
