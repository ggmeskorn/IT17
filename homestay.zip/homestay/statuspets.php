<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$id = $_POST['id'];
$db->query("UPDATE petss SET statuspets = 'มีคนรับเลี้ยงแล้ว'  WHERE id = '".$id."'");