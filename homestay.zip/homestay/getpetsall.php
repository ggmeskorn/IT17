<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$list = array();
$username = $_GET['username'];

$result = $db->query("SELECT DISTINCT p.id ,p.namepets ,p.detailspets,p.category_pets,p.genderpets,p.sterillzationpets,p.vaccinepets,p.bodysize,p.statuspets,p.typebreed ,p.pathimagepets ,ua.username,ua.pathImage, p.create_at, p.update_at ,p.lat,p.lone ,cp.name_category FROM petss as p LEFT JOIN category_pets as cp ON p.category_pets = cp.id LEFT JOIN user_admin as ua ON p.id_user = ua.id GROUP BY p.id DESC
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
