<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$list = array();
$username = $_GET['username'];

$result = $db->query("SELECT n.id,ua.username,n.title,n.body,n.category_news,n.update_at,n.created_at,n.pathImagenews,n.Views FROM news as n LEFT JOIN user_admin as ua ON ua.id = n.admin_id ORDER BY n.Views DESC
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
