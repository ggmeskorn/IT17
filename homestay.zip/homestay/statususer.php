<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$id = $_POST['id'];
$id_adopt = $_GET['id_adopt'];
$db->query("UPDATE petss SET id_adopt = '$id_adopt'  WHERE id = '".$id."'");