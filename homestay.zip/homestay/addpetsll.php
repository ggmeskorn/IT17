<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
// $image_post = $_POST['image_post'];
$id_adopt = $_POST['id_adopt'];
$id_user = $_POST['id_user'];
$namepets = $_POST['namepets'];
$detailspets = $_POST['detailspets'];
$genderpets = $_POST['genderpets'];
$sterillzationpets = $_POST['sterillzationpets'];
$category_pets = $_POST['category_pets'];
$vaccinepets = $_POST['vaccinepets'];
$bodysize = $_POST['bodysize'];
$typebreed = $_POST['typebreed'];
$lat = $_POST['lat'];
$lone = $_POST['lone'];
$create_at = date('d/m/Y ');
$update_at = $_POST['update_at'];
$pathimagepets = $_FILES['pathimagepets']['name'];
$imagePath = "Pets/" . $pathimagepets;

$tmp_name =  $_FILES['pathimagepets']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

// $db->query("INSERT INTO post_table(image_post,title_post,body_post,category_name,post_date,comments_post,total_Like,create_date,author_post)VALUES('" . $image_post . "','" . $title_post . "','" . $body_post . "','" . $category_name . "','" . $post_date . "',0,0,'" . $create_date . "','" . $author_post . "')");

$db->query("INSERT INTO petss(pathimagepets,id_user,id_adopt,namepets,detailspets,genderpets,category_pets,sterillzationpets,vaccinepets,bodysize,typebreed,lat,lone,statuspets,create_at,update_at)
 VALUES('" . $pathimagepets . "','" . $id_user . "','0','" . $namepets . "','" . $detailspets . "','" . $genderpets . "','" . $category_pets . "','" . $sterillzationpets . "','" . $vaccinepets . "','" . $bodysize . "','" . $typebreed . "','" . $lat . "','" . $lone . "','ยังไม่มีผู้รับเลี้ยง','" . $create_at . "','" . $update_at . "')");