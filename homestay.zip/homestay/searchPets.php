<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$search1 = $_POST['namepets'];
$search2 = $_GET['statuspets'];
$search3 = $_GET['category_pets'];
$search4 = $_GET['genderpets'];
$search5 = $_POST['bodysize'];
$search6 = $_POST['sterillzationpets'];
$search7 = $_POST['vaccinepets'];


$list = array();
$searchStatus = 0;
$search = $_GET["s"];
// $result = $db->query("SELECT DISTINCT p.id ,p.namepets ,p.detailspets,p.category_pets,p.genderpets,p.sterillzationpets,p.vaccinepets,p.bodysize,p.statuspets,p.typebreed ,i.pathimage ,u.username,u.pathImage, p.create_at, p.update_at ,p.lat,p.lone,u.username,u.gender,u.status FROM petss as p LEFT JOIN image_pets as i on p.id = i.id_pets LEFT JOIN user_admin as u on p.id_user = u.id WHERE p.genderpets Like  '%" . $search . "%' , GROUP BY p.id
// " );
$result = $db->query("SELECT DISTINCT p.id ,p.namepets ,p.detailspets,p.category_pets,p.genderpets,p.sterillzationpets,p.vaccinepets,p.bodysize,p.statuspets,p.typebreed ,p.pathimagepets ,u.username,u.pathImage, p.create_at, p.update_at ,p.lat,p.lone,u.username,u.gender,u.status
 FROM petss as p LEFT JOIN user_admin as u on p.id_user = u.id 
 WHERE  p.category_pets LIKE '$search3' AND p.genderpets LIKE '$search4' AND p.statuspets LIKE '$search2'  GROUP BY p.id 
");
if ($result) {  
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {

        $list[] = $row;
        
    }
}
    
    // while ($row = $result->fetch_assoc()) {
    //     $list[] = $row;
    // }
    echo json_encode($list);
    // OR p.statuspets Like '%" . $search2 . "%' OR p.genderpets  Like '%" . $search4 . "%' OR p.sterillzationpets Like '%" . $search6 . "%' OR p.vaccinepets  Like '%" . $search7 . "%' OR p.bodysize Like '%" . $search5 . "%' 

}
