<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$list = array();
$id = $_GET['id'];

$result = $db->query("SELECT DISTINCT p.id ,p.namepets ,p.detailspets,p.category_pets,p.genderpets,p.sterillzationpets,p.vaccinepets,p.bodysize,p.statuspets,p.typebreed ,p.pathimagepets,ua.username,ua.pathImage, p.create_at, p.update_at ,p.lat,p.lone FROM petss as p LEFT JOIN user_admin as ua ON p.id_user = ua.id WHERE ua.id = '$id' GROUP BY p.id



");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
