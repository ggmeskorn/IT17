<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$id = $_POST['id'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
// $pathImage = $_POST['pathImage'];
$status = $_POST['status'];
$phone = $_POST['phone'];
$pathImage = $_FILES['pathImage']['name'];
$imagePath = "Users/" . $pathImage;

$tmp_name =  $_FILES['pathImage']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

$db->query("UPDATE user_admin SET pathImage = '" . $pathImage . "', email = '".$email."',username = '".$username."', password = '".$password."',phone = '".$phone."',gender = '".$gender."'WHERE id = '".$id."' ");
