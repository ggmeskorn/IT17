<?php
$db = mysqli_connect("localhost", "root", "", "final_project");

if (!$db) {
    printf("Database connect error", mysqli_connect_error());
}
$id_adopt = $_POST['id_adopt'];
$id_user = $_POST['id_user'];
$namepets = $_POST['namepets'];
$detailspets = $_POST['detailspets'];
$genderpets = $_POST['genderpets'];
$sterillzationpets = $_POST['sterillzationpets'];
$category_pets = $_POST['category_pets'];
$vaccinepets = $_POST['vaccinepets'];
$bodysize = $_POST['bodysize'];
$typebreed = $_POST['typebreed'];
$lat = $_POST['lat'];
$lone = $_POST['lone'];
$create_at = date('d/m/Y ');
$update_at = $_POST['update_at'];

$db->query("INSERT INTO petss(id_user,id_adopt,namepets,detailspets,genderpets,category_pets,sterillzationpets,vaccinepets,bodysize,typebreed,lat,lone,statuspets,create_at,update_at)
 VALUES('" . $id_user . "','" . $id_adopt . "','" . $namepets . "','" . $detailspets . "','" . $genderpets . "','" . $category_pets . "','" . $sterillzationpets . "','" . $vaccinepets . "','" . $bodysize . "','" . $typebreed . "','" . $lat . "','" . $lone . "','ยังไม่มีผู้รับเลี้ยง','" . $create_at . "','" . $update_at . "')");
    // $sql = "INSERT INTO `register`(`id`, `email`, `username`,`password`,`gender`,`pathImage`,`status`) VALUES (Null, '$email','$username','$password','$gender','$pathImage','$status')";

    // $db->query("INSERT INTO comment(comments,author_post,user_email,post_id,comments_date,isSeen)VALUES('".$comments."','".$author_post."','".$user_email."','".$post_id."','".$curDate."',0)");
