<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
// $image_post = $_POST['image_post'];
$post_date =  $_POST['update_date'];
$comments_post =   $_POST['comments_post'];
$total_Like =   $_POST['total_Like'];
$title_post =   $_POST['title_post'];
$category_name =   $_POST['category_name'];
$create_date =  date('d/m/Y ');
$author_post =   $_POST['author_post'];
$body_post =  $_POST['body_post'];
$image_post = $_FILES['image_post']['name'];
$imagePath = "Post/" . $image_post;

$tmp_name =  $_FILES['image_post']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

$db->query("INSERT INTO post_table(image_post,title_post,body_post,category_name,update_date,comments_post,total_Like,create_date,author_post)VALUES('" . $image_post . "','" . $title_post . "','" . $body_post . "','" . $category_name . "','" . $post_date . "',0,0,'" . $create_date . "','" . $author_post . "')");

