<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$id = $_POST['id'];
$admin_id =  $_POST['admin_id'];
$title =   $_POST['title'];
$body =  $_POST['body'];
$category_news =   $_POST['category_news'];
$create_date =  date('d/m/Y h:i');
$pathImagenews = $_FILES['pathImagenews']['name'];
$imagePath = "News/" . $pathImagenews;

$tmp_name =  $_FILES['pathImagenews']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

$db->query("UPDATE news SET pathImagenews = '" . $pathImagenews . "', admin_id = '" . $admin_id . "',update_at = '" . $create_date . "', title = '" . $title . "',body = '" . $body . "',category_news = '" . $category_news . "'WHERE id = '" . $id . "' ");
