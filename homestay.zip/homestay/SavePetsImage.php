<?php
$db = mysqli_connect('localhost','root','','final_project');
    
    $image[] = $_FILES['image']['name'];
    $tmpFile[] = $_FILES['image']['tmp_name'];
    
    foreach ($image as $key => $value){
        foreach ($tmpFile as $key => $tmpFilevalue){
            if (move_uploaded_file($tmpFilevalue, 'Pets/'.$value)){
            $save = $db->query("INSERT INTO petss(PathImage)VALUES('".$value."')");
            if ($save){
                echo json_encode(array("massage" =>"Success"));
            }else{
                echo json_encode(array("massage" =>"Error ".mysqli_error($db)));
             }
          }
       }
    }
    ?>
