<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$name_category = $_POST['name_category'];
$list = array();
$result = $db->query("SELECT DISTINCT p.id ,p.namepets ,p.detailspets,p.category_pets,p.genderpets,p.sterillzationpets,p.vaccinepets,p.bodysize,p.statuspets,p.typebreed ,i.pathimage ,ua.username,ua.pathImage, p.create_at, p.update_at ,p.lat,p.lone,p.pathimagepets FROM petss as p LEFT JOIN image_pets as i on p.id = i.id_pets LEFT JOIN user_admin as ua ON p.id_user = ua.id WHERE category_pets = '" . $name_category . "' GROUP BY p.id

 ");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
