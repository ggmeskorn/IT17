<?php
header("content-type:text/javascript;charset=utf-8");
error_reporting(0);
error_reporting(E_ERROR | E_PARSE);
$link = mysqli_connect('localhost', 'root', '', "final_project");

if (!$link) {
	echo "Error: Unable to connect to MySQL." . PHP_EOL;
	echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
	echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;

	exit;
}

if (!$link->set_charset("utf8")) {
	printf("Error loading character set utf8: %s\n", $link->error);
	exit();
}

if (isset($_GET)) {
	if ($_GET['isAdd'] == 'true') {
		// $id_user = $_GET['id_user'];
		// $namepets = $_GET['namepets'];
		// $detailspets = $_GET['detailspets'];
		// $category_pets = $_GET['category_pets'];
		// $genderpets = $_GET['genderpets'];
		// $sterillzationpets = $_GET['sterillzationpets'];
		// $vaccinepets = $_GET['vaccinepets'];
		// $bodysize = $_GET['bodysize'];
		// $typebreed =  $_GET['typebreed'];
		// $lat = $_GET['lat'];
		// $lone = $_GET['lone'];
		// $status = $_GET['status'];
		// $status_online = $_GET['status_online'];
		// // $create_at = date('d/m/Y');
		// $update_at = $_GET['update_at'];
		$id_user = $_GET['id_user'];
		// $sql = "INSERT INTO `pets` (`id`, `id_user`, `namepets`,`detailspets`,`category_pets`,`genderpets`,`sterillzationpets`,`vaccinepets`,`bodysize`,
		// `typebreed`,`lat`,`lone`,`status`,`status_online`,`create_at`,`update_at`) VALUES (null,'$id_user','$namepets','$detailspets','$sterillzationpets','$vaccinepets','$bodysize','$typebreed','$lat','$lone','$status','$status_online','$update_at')";
		// $result = mysqli_query($link, $sql);
		// $ins = "INSERT INTO `image_pets`(`pathimage`,`id_pets`) VALUES (null,'$pathimage','$id_pets')";
		// $result = mysqli_query($link, $ins);
$sql =  "INSERT INTO 'pets' ('id','id_user') VALUES(null,'$id_user')";
		if ($result) {
			echo "true";
		} else {
			echo "false";
		}
	} else echo "Welcome ";
}
mysqli_close($link);
