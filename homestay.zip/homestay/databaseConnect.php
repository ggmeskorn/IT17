<?php
$dbhost = 'localhost';
$dbuser='root';
$dbpass='';
$dbname='final_project';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
mysqli_set_charset($conn, "utf8"); /* Procedural approach */
date_default_timezone_set('Asia/Bangkok');
$conn->set_charset("utf8");        /* Object-oriented approach */
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
  echo "Connection failed: " . $conn->connect_error;
}