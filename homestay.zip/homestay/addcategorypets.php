<?php
 
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
    $name_category = $_POST['name_category'];
    $curDate = date('d/m/Y');
    // $create_at = $_POST['create_at'];
    $update_at = $_POST['update_at'];


    // $sql = "INSERT INTO `register`(`id`, `email`, `username`,`password`,`gender`,`pathImage`,`status`) VALUES (Null, '$email','$username','$password','$gender','$pathImage','$status')";

    $db->query("INSERT INTO category_pets(name_category,create_at,update_at)VALUES('".$name_category."','".$curDate."','".$update_at."')");

    ?>