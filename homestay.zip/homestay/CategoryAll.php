<?php
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
$list = array();
 $result = $db->query("SELECT * FROM category");
 if($result){
    while($row = $result->fetch_assoc()){
        $list[] = $row;
    }
    echo json_encode($list);

 }
?>