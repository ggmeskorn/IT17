<?php
header("content-type:text/javascript;charset=utf-8");
error_reporting(0);
error_reporting(E_ERROR | E_PARSE);
$link = mysqli_connect('localhost', 'root', '', "final_project");

if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    
    exit;
}

if (!$link->set_charset("utf8")) {
    printf("Error loading character set utf8: %s\n", $link->error);
    exit();
	}

if (isset($_GET)) {
	if ($_GET['isAdd'] == 'true') {
				
		$id_Pets = $_GET['id_Pets'];
       
  

        $sql = "DELETE FROM `Petss` WHERE id_Pets = '$id_Pets'";
//		$sql = "INSERT INTO `pets`(`id_pets`, `User_admin_id`, `Name_Pets`, `Detail_Pets`, `Type_Breed`, `Age_Pets`, `Gender_Pets`, `Vaccine_Pets`, `Habit_Pets`, `Image_Pets`, `Sterillzation_Pets`, `Status`, ) VALUES (null,'$User_admin_id','$Name_Pets','$Detail_Pets','$Type_Breed','$Age_Pets','$Gender_Pets','$Vaccine_Pets','$Habit_Pets','$Image_Pets','$Sterillzation_Pets','$Status')";

		$result = mysqli_query($link, $sql);

		if ($result) {
			echo "true";
		} else {
			echo "false";
		}

	} else echo "Welcome Master UNG";
   
}
	mysqli_close($link);
?>
